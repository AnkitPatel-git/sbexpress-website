<?php

$con = mysqli_connect("localhost","sbexpres_rushi","a3227240","sbexpres_cargo");


?>