<?php include 'core/int.php';
admin_protect();
protect_page(); 
 ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Update Web Bill  | SB Express Cargo LLp Courier </title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="dist/css/font-awesome.min.css">
<link rel="stylesheet" href="dist/css/ionicons.min.css">
<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
<link rel="stylesheet" type="text/css" href="formvalidation/vendor/formvalidation/css/formValidation.min.css">
<link rel="stylesheet" href="dist/css/pnotify.custom.min.css">
<link rel="stylesheet" href="dist/css/jquery-ui.min.css">

<link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Main Header -->
  <?php include'include/header.php'; ?>
  <!-- Left side column. contains the logo and sidebar -->
 <?php include'include/menu.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update Web Bill
        <small>Optional description</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active"> Update Web Bill</li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
   <div class="row">

    <div class="col-md-12">
     <div class="box box-primary">
      <div class="box-header with-border">
       <h3 class="box-title"> Update Web Bill</h3>
      </div>
      <div class="box-body">
          <?php 

            $id = $_GET['id'];
            $get = mysqli_query($con,"select * from excel where id = '$id'");

            $show = mysqli_fetch_array($get);

          ?>
        <form id="web-bill-form" method="post" action="ajax/Update/Update-Web-Bill.php" class="form-horizontal" enctype="multipart/form-da">

          <div class="form-group">
              <label class="control-label col-md-3">Web Bill No</label>
                <div class="col-md-5">
                  <input type="text"  class="form-control" name="bill_no" placeholder="Web Bill No" value="<?php echo $show['Bill_No'];?>" />
                </div>
                <input type="hidden" name="bill_id" value="<?php echo $show[0]?>">
                 <input type="hidden" name="bill_file" value="<?php echo $show['File']?>">
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">File Select</label>
                <div class="col-md-5">
                  <input type="file"  class="form-control" name="excel_file" placeholder="File Select"  />
                </div>
            </div>
             <div class="form-group">
              <label class="control-label col-md-3">Pickup Date</label>
                <div class="col-md-5">
                  <input type="text" class="form-control" name="pick_date" placeholder="Pickup Date" 
                  value="<?php echo $show['Pick_Date'];?>"/>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-3 control-label">From</label>
                <div class="col-md-5">
                    <input type="text" class="form-control" name="from" placeholder="From" value="<?php echo $show['From_City'];?>"/>
                </div>
            </div>
            
            <div class="form-group">
              <label class="control-label col-md-3">To</label>
                <div class="col-md-5">
                  <input type="text" class="form-control" name="to"  placeholder="To"  value="<?php echo $show['To_City'];?>"/>
                </div>
            </div>
            
            <div class="form-group">
              <label class="control-label col-md-3">Status</label>
                <div class="col-md-5">
                  <input type="text" class="form-control" name="status" placeholder="Status"  value="<?php echo $show['Status'];?>"/>
                </div>
            </div>
            
            <div class="form-group">
              <label class="control-label col-md-3">Date of Delivery</label>
                <div class="col-md-5">
                  <input type="text" class="form-control" name="deli_date" placeholder="Date of Delivery"  value="<?php echo $show['Deli_Date'];?>"/>
                </div>
            </div>
            
            <div class="form-group">
              <label class="control-label col-md-3">Time of Delivery </label>
                <div class="col-md-5">
                  <input type="text"  class="form-control" name="deli_time"  placeholder="Time of Delivery" value="<?php echo $show['Deli_Time'];?>"/>
                </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Description</label>
                <div class="col-md-5">
                  <textarea rows="4" class="form-control" name="des" placeholder="Description"><?php echo $show['Des'];?></textarea> 
                </div>
            </div> 
            
            
            
            

            <div class="form-group">
                <div class="col-md-9 col-md-offset-3">
                    <button type="submit" class="btn btn-success" name="save">Save</button>
                </div>
            </div>
        </form>

      </div>
     </div>
    </div>




   </div>
  </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <?php include'include/footer.php'; ?>

</div>

<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="dist/js/app.min.js"></script>
<script src="formvalidation/vendor/formvalidation/js/formValidation.min.js"></script>
<script src="formvalidation/vendor/formvalidation/js/framework\bootstrap.min.js"></script>
<script src="dist/js/pnotify.custom.min.js"></script>
<script src="dist/js/jquery-ui.min.js"></script>
<script>
$(document).ready(function(){

  var notr = function(){
    new PNotify({
        title: 'Success',
    text: 'Data Successfully Saved',
    type: 'success',
    });
  }

 

  $('#web-bill-form')
  .find('[name="pick_date"]')
  .datepicker({
    changeMonth: true,
      changeYear: true,
      dateFormat: 'dd-mm-yy',
      onSelect: function(date, inst) {
          /* Revalidate the field when choosing it from the datepicker */
          $('#web-bill-form').formValidation('revalidateField', 'pick_date');
      }
  });
   $('#web-bill-form')
  .find('[name="deli_date"]')
  .datepicker({
    changeMonth: true,
      changeYear: true,
      dateFormat: 'dd-mm-yy',
      onSelect: function(date, inst) {
          /* Revalidate the field when choosing it from the datepicker */
          $('#web-bill-form').formValidation('revalidateField', 'deli_date');
      }
  });

   $('#web-bill-form')
        .formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
       bill_no: {
          validators: {
            notEmpty: {
              message: 'The State Name is Required' 
            },
             
            stringLength: {
                        max: 11,
                        min:11,
                        message: 'The web bill no is 11 digit'
            },
            numeric:{
              message:'The web bill no is numeric'
            }
          }
        },
        pick_date : {
          validators: {
            notEmpty: {
              message: 'The pickup date is Required'  
            }
          }
        },
          
        
      }
    }).on('success.form.fv', function(e) {
            // Prevent form submission
            e.preventDefault();

            var $form    = $(e.target),
                formData = new FormData(),
                params   = $form.serializeArray(),
                files    = $form.find('[name="excel_file"]')[0].files;

            $.each(files, function(i, file) {
                formData.append('excel_file', file);
            });
            $.each(params, function(i, val) {
                formData.append(val.name, val.value);
            });
    $.ajax({
       type: 'POST',
        url: $form.attr('action'),
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        beforeSend: function() {
          $('#web-bill-form button').html('red');
        },
        success: function(result) {
          $('#web-bill-form button').html('Save');
          notr();
          setTimeout(function(){ window.location.href = 'manage-web-bill-no.php' }, 1200);
        }
    });
  });

     

});
</script>

</body>
</html>
