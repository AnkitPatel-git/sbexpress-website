-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2016 at 07:36 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_settings`
--

CREATE TABLE `account_settings` (
  `AID` int(11) NOT NULL,
  `TDS` int(11) NOT NULL,
  `Donation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_settings`
--

INSERT INTO `account_settings` (`AID`, `TDS`, `Donation`) VALUES
(1, 10, 21);

-- --------------------------------------------------------

--
-- Table structure for table `domestic_doc`
--

CREATE TABLE `domestic_doc` (
  `id` int(11) NOT NULL,
  `State` varchar(100) NOT NULL,
  `IN_Vat` varchar(200) NOT NULL,
  `Validity_Form` varchar(100) NOT NULL,
  `Tax` varchar(100) NOT NULL,
  `Octroi` varchar(100) NOT NULL,
  `Out_Vat` varchar(100) NOT NULL,
  `Remark` text NOT NULL,
  `Link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `domestic_doc`
--

INSERT INTO `domestic_doc` (`id`, `State`, `IN_Vat`, `Validity_Form`, `Tax`, `Octroi`, `Out_Vat`, `Remark`, `Link`) VALUES
(2, 'ANDHRA PRADESH', 'INVOICE', 'NA', 'NO', 'NO', 'VAT FORM 10 OR 600', 'TIN NUMBER OF CONSIGNEE IS MUST ON INVOICE', 'http://www.apcomercialtaxes.gov.in\n'),
(5, 'ANDAMAN & NICOBAR', 'INVOICE', 'NA', 'NO', 'NO', 'NA\r\n\r\n', 'TIN NUMBER OF CONSIGNEE IS MUST ON INVOICE', 'http://www.and.nic.in/'),
(7, 'ASSAM', 'FORM NO.62(PERSONAL USE & CAPITAL GOODS), FORM 24(FOR SALE), DELIVERY NOTE\r\n\r\n', 'FORM 61 - 180 DAYS; FORM 62 - 2 MONTHS FROM DATE OF ISSUE)', 'YES', 'NO', 'VAT FORM 63 FOR PERSONAL USE & CAPITAL GOODS; VAT FORM 25 FOR SALES\r\n\r\n', '', 'http://www.taxassam.co.in/'),
(8, 'BIHAR', 'Any consignment Value is more than Rs.10,000/- E-Suvidha & Original Invoice\r\n\r\n', 'NA', 'NO', 'NO', 'VAT FORM -D-10\r\n\r\n', 'Any consignment Value is less than Rs.10,ooo/- Â  thenÂ  only original Invoice & C10 Form is required.\r\n\r\n', 'http://www.biharcommercialtax.gov.in/'),
(9, 'CHANDIGARH', 'INVOICE\r\n\r\n', '', '#YES( 4% )', 'NO', '', 'TIN NUMBER OF CONSIGNEE AND CONSIGNOR IS MUST ON INVOICE\r\n\r\n', 'http://www.chandigarh.gov.in/'),
(10, 'CHATTISGARH', 'FORM-59(A) & INVOICE\r\n\r\n', 'NA', 'NO', 'NO', '', '', 'http://www.comtax.cg.nic.in/'),
(11, 'DADRA & NAGAR HAVELI', 'FORM-403 & INVOICE\r\n\r\n', 'NA', 'NO', 'NO', 'FORM-402 WITH INVOICE\r\n\r\n', '', 'http://www.dnh.nic.in/'),
(12, 'DELHI', 'FORM-DS2(DELHI SUGAM2) & INVOICE\r\n\r\n', 'NA', 'NO', 'NO', '', '', 'http://www.dvat.nic.in/'),
(14, 'DAMAN & DIU', 'FORM-403 & INVOICE\r\n\r\n', 'NA', 'NO', 'NO', 'FORM-402 WITH INVOICE\r\n\r\n', '', 'http://www.daman.nic.in/'),
(15, 'GOA', 'INVOICE\r\n\r\n', 'NA', 'NO', 'NO', '', '', 'http://www.goasalestax.com/'),
(16, 'GUJARAT', 'FORM 403 & INVOICE\r\n\r\n', 'NA', 'NO', 'NO', 'FORM-402\r\n\r\n', '', 'http://www.commercialtax.gujarat.gov.in/'),
(17, 'HARYANA', 'FORM - 38 (for value more than Rs.24,500/-) & INVOICE\r\n\r\n', 'AS PER 90 DAYS MENTIONED ON THE FORM', 'NO', 'NO', 'FORM F-38 (for value more than Rs.24,500/-)\r\n\r\n', '', 'http://www.haryanatax.com/'),
(18, 'HIMACHAL PRADESH', 'INVOICE WITH ENTRY FORM WHICH IS FILLED AT BARRIER (HP PERMIT - 26)\r\n\r\n', '30 DAYS FROM THE DATE OF ISSUE', 'YES', 'NO', 'HP PERMIT - 26\r\n\r\n', '', 'http://www.hplax.nic.in/'),
(19, 'JAMMU & KASHMIR', 'VAT FORM 65 for value Rs. 5000 and above\r\n\r\n', 'NA', 'YES', 'NO', 'VAT Form 65\r\n\r\n', '', 'http://www.jkcomtx.nic.in/'),
(20, 'JHARKHAND', 'FORM JVAT 504G\r\n\r\n', 'AS PER DATES MENTIONED ON THE FORM', 'NO', 'NO', 'FORM JVAT 504B\r\n\r\n', '', 'http://www.jharkhandcomtax.nic.in/'),
(21, 'KARNATAKA', 'Invoice & E-Sugam Form\r\n\r\n', 'NA', 'NO', 'NO', 'INVOICE AND E-SUGAM FORM Â \r\n\r\n', 'EXEMPTED FOR RAW FABRICS, VACCINE AND MEDICINEÂ \r\n\r\n', 'http://www.ctax.kar.nic.in/'),
(22, 'KERALA', 'In case of Registered Firm: Online form 8 FA along with Invoice; In case of Individual: Form 16 & Invoice; Incase of Stock transfer: Form 15 &Invoice.\r\n', 'NA', 'NO', 'NO', 'FORM-27b AND TIN NO should be mentioned in invoice. Declaration is must for all the parcel shipments', '', 'http://www.keralaxes.org/'),
(23, 'MADHYA PRADESH', 'FORM- 49 FOR AIR AND FORM 60 FOR TRAIN LOADS\r\n\r\n', 'NA', 'NO', 'NO', '', 'FORM 50 FOR PERSONAL USE AND STOCK TRANSFER\r\n\r\n', 'http://www.mptax.mp.gov.in/'),
(24, 'LAKSHDWEEP', 'Invoice\r\n', 'NA', 'NO', 'NO', '', '', 'http://www.lakshadweep.nic.in/'),
(25, 'MAHARASHTRA', 'INVOICE\r\n\r\n', 'NA', 'NO', 'YES', '', '', 'http://www.vat.maharashtra.gov.in/'),
(26, 'MANIPUR', 'ST-35(3 copies)\r\n\r\n', 'VALID FOR 120 DAYS FROM THE DATE OF ISSUE', 'NO', 'NO', 'ST-36\r\n\r\n', 'FORM 37 IS FOR PERSONAL SHIPMENTS\r\n\r\n', 'http://www.manipurtaxation.nic.in/'),
(27, 'MEGHALAYA', 'VAT FORM - 40 & INVOICE\r\n\r\n', 'VALID FOR 90 DAYS FROM DATE OF ISSUE', 'NO', 'NO', 'VAT FORM 37\r\n\r\n', '', 'http://www.megvat.nic.in/'),
(28, 'MIZORAM (Aizawl)', 'VAT FORM-33 & INVOICE\r\n\r\n', 'VALID FOR 30 DAYS FROM THE DATE OF ISSUE', 'NO', 'NO', '', '', 'http://www.mizoram.nic.in/'),
(29, 'NAGALAND', 'FORM-16 & INVOICE\r\n\r\n', '', 'NO', 'NO', '', '', 'http://www.nagaland.nic.in/'),
(30, 'ORISSA', 'VAT FORM 32 FOR REGISTERED FIRMS AND FORM 402 FOR UNREGISTERED FIRMS\r\n\r\n', '31ST MARCH OF EVERY YEAR', 'YES', 'NO', 'VAT FORM 402\r\n\r\n', 'FORM 402 A MUST FOR UNREGISTERED FIRMS / ENTRY TAX APPLICABLE FOR SUCH SHIPMENTS\r\n\r\n', 'http://www.orissatax.gov.in/'),
(31, 'PONDICHERRY', 'INVOICE WITH TIN NUMBER\r\n\r\n', 'NA', 'NO', 'NO', '', '', 'http://www.vat.pon.nic.in/'),
(32, 'PUNJAB', 'Invoice with Entry Form which is filled at Barrier\r\n\r\n', 'NA', '# YES(4%)', 'NO', '', 'INVOICE WITH TIN NO\r\n\r\n', 'http://www.pextax.com/'),
(33, 'RAJASTHAN', 'VAT FORM: 47 & INVOICE\r\n\r\n', 'THREE YEARS FROM THE DATE OF ISSUE', 'YES', 'NO', 'VAT FORM: 49\r\n\r\n', '', 'http://www.rajtax.gov.in/'),
(34, 'SIKKIM', 'VAT FORM - 25 & INVOICE\r\n', 'SIX MONTHS FROM THE DATE OF ISSUE', 'NO', 'NO', '', '', 'http://www.sikkim.gov.in/'),
(35, 'TAMIL NADU', 'INVOICE WITH TIN NUMBER\r\n\r\n', 'NA', 'NO', 'NO', 'JJ FORM\r\n\r\n', '', 'www.tnvat.gov.in'),
(36, 'TRIPURA', 'VAT FORM-24 & INVOICE\r\n\r\n', 'NA', 'NO', 'NO', 'FORM 26\r\n\r\n', '', 'www.tripura.nic.in'),
(37, 'TELANGANA', 'INVOICE\r\n', 'NA', 'NO', 'NO', 'VAT FORM 10 OR 600\r\n', 'TIN NUMBER OF CONSIGNEE IS MUST ON INVOICE\r\n', ''),
(38, 'UTTAR PRADESH', 'FORM 38 FOR REGISTERED FIRM; VAT FORM 39 FOR INDIVIDUALS AND INVOICE\r\n\r\n\r\n', 'SERIES AS PER NOTIFICATION OF SALES TAX AUTHORITIES', 'NO', 'NO', '', '', 'www.comtaxup.nic.in'),
(39, 'UTTARANCHAL', 'FORM 16 FOR REGISTERED & FORM 17 FOR INDIVIDUAL; INVOICE\r\n', 'ONE MONTH FROM THE DATE OF ISSUE', 'NO', 'NO', '', '', 'www.gov.ua.nic.in'),
(40, 'WEST BENGAL', 'VAT FORM-50 Along with Part 2 of form & INVOICE\r\n\r\n', 'ONE YEAR FROM THE DATE OF ISSUE', 'NO', 'NO', 'VAT FORM-51\r\n\r\n', '', 'www.wbcomtax.nic.in'),
(41, 'ARUNACHAL PRADESH', 'FORM FF07& INVOICE\r\n\r\n', 'NA', 'YES', 'NO', 'NA', 'TIN NUMBER OF CONSIGNEE IS MUST ON INVOICE\r\n\r\n', 'www.arunachalpradesh.nic.in');

-- --------------------------------------------------------

--
-- Table structure for table `excel`
--

CREATE TABLE `excel` (
  `id` int(11) NOT NULL,
  `Bill_No` varchar(100) NOT NULL,
  `File` text NOT NULL,
  `Pick_Date` varchar(100) NOT NULL,
  `Deli_Date` varchar(100) NOT NULL,
  `From_City` varchar(100) NOT NULL,
  `To_City` varchar(100) NOT NULL,
  `Deli_Time` varchar(100) NOT NULL,
  `Des` text NOT NULL,
  `Status` varchar(200) NOT NULL,
  `Rand` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `excel`
--

INSERT INTO `excel` (`id`, `Bill_No`, `File`, `Pick_Date`, `Deli_Date`, `From_City`, `To_City`, `Deli_Time`, `Des`, `Status`, `Rand`) VALUES
(1, '33528998576', '24600Book1.xlsx', '18-11-2016', '23-11-2016', 'Mumbai', 'Thane', '12:00 AM', 'testewf', 'Shipment Delivered', '28442');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `Username` varchar(32) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Bill_No` varchar(100) NOT NULL,
  `First_Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL,
  `Email` varchar(32) NOT NULL,
  `Active` int(11) NOT NULL DEFAULT '1',
  `Type` int(1) NOT NULL DEFAULT '0',
  `Rights` varchar(50) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Original_Password` varchar(50) NOT NULL,
  `Address` text NOT NULL,
  `State` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Pincode` varchar(100) NOT NULL,
  `Date_of_Joint` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Profile_Pic` varchar(2000) NOT NULL,
  `Cover_Photo` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `Username`, `Password`, `Bill_No`, `First_Name`, `Last_Name`, `Email`, `Active`, `Type`, `Rights`, `Mobile`, `Original_Password`, `Address`, `State`, `City`, `Pincode`, `Date_of_Joint`, `Profile_Pic`, `Cover_Photo`) VALUES
(1, 'rushikesh', '1212c2ece5b6a408fa5c2da29389df8d', '', 'Rushikesh', 'Awatade', 'rushiawatade@gmail.com', 1, 1, 'Admin', 9664747865, 'a3227240', '', '', '', '', '2016-09-09 12:13:06', '', ''),
(632, '', '', '33528998576', '', '', '', 1, 0, '', 0, '', '', '', '', '', '2016-11-21 08:39:35', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `UL_ID` int(11) NOT NULL,
  `User_ID` bigint(20) NOT NULL,
  `Year` varchar(10) NOT NULL,
  `Months` varchar(10) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Log_Type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`UL_ID`, `User_ID`, `Year`, `Months`, `Date`, `Time`, `Log_Type`) VALUES
(1, 1, '2016', 'Sep', '2016-09-30', '01:36:54', 'Login'),
(2, 8, '2016', 'Oct', '2016-10-01', '15:15:58', 'Login'),
(3, 1, '2016', 'Oct', '2016-10-01', '15:34:53', 'Login'),
(4, 1, '2016', 'Oct', '2016-10-01', '16:22:11', 'Login'),
(5, 8, '2016', 'Oct', '2016-10-01', '17:03:17', 'Login'),
(6, 1, '2016', 'Oct', '2016-10-01', '17:17:44', 'Login'),
(7, 1, '2016', 'Oct', '2016-10-01', '18:40:58', 'Login'),
(8, 1, '2016', 'Oct', '2016-10-03', '19:24:19', 'Login'),
(9, 1, '2016', 'Oct', '2016-10-03', '20:18:40', 'Login'),
(10, 1, '2016', 'Oct', '2016-10-03', '20:19:04', 'Login'),
(11, 1, '2016', 'Oct', '2016-10-03', '20:27:40', 'Login'),
(12, 1, '2016', 'Oct', '2016-10-03', '07:04:30', 'Login'),
(13, 1, '2016', 'Oct', '2016-10-03', '07:09:16', 'Login'),
(14, 1, '2016', 'Oct', '2016-10-03', '10:19:18', 'Login'),
(15, 1, '2016', 'Oct', '2016-10-03', '11:22:52', 'Login'),
(16, 1, '2016', 'Oct', '2016-10-04', '05:33:44', 'Login'),
(17, 1, '2016', 'Oct', '2016-10-04', '06:04:27', 'Login'),
(18, 1, '2016', 'Oct', '2016-10-04', '06:12:27', 'Login'),
(19, 1, '2016', 'Oct', '2016-10-04', '07:34:28', 'Login'),
(20, 1, '2016', 'Oct', '2016-10-04', '09:55:28', 'Login'),
(21, 1, '2016', 'Oct', '2016-10-04', '09:55:43', 'Login'),
(22, 1, '2016', 'Oct', '2016-10-04', '10:15:51', 'Login'),
(23, 1, '2016', 'Oct', '2016-10-04', '15:24:55', 'Login'),
(24, 1, '2016', 'Oct', '2016-10-04', '17:52:17', 'Login'),
(25, 1, '2016', 'Oct', '2016-10-04', '17:56:44', 'Login'),
(26, 1, '2016', 'Oct', '2016-10-05', '06:28:29', 'Login'),
(27, 1, '2016', 'Oct', '2016-10-05', '07:39:49', 'Login'),
(28, 1, '2016', 'Oct', '2016-10-05', '09:13:53', 'Login'),
(29, 1, '2016', 'Oct', '2016-10-05', '10:27:58', 'Login'),
(30, 1, '2016', 'Oct', '2016-10-05', '13:33:33', 'Login'),
(31, 1, '2016', 'Oct', '2016-10-06', '05:53:41', 'Login'),
(32, 15, '2016', 'Oct', '2016-10-06', '06:57:20', 'Login'),
(33, 1, '2016', 'Oct', '2016-10-06', '08:11:53', 'Login'),
(34, 1, '2016', 'Oct', '2016-10-06', '09:21:19', 'Login'),
(35, 15, '2016', 'Oct', '2016-10-06', '09:33:39', 'Login'),
(36, 1, '2016', 'Oct', '2016-10-07', '04:57:01', 'Login'),
(37, 1, '2016', 'Oct', '2016-10-07', '04:57:23', 'Login'),
(38, 1, '2016', 'Oct', '2016-10-07', '08:06:33', 'Login'),
(39, 1, '2016', 'Oct', '2016-10-07', '16:10:48', 'Login'),
(40, 1, '2016', 'Oct', '2016-10-09', '05:00:26', 'Login'),
(41, 1, '2016', 'Oct', '2016-10-09', '05:07:26', 'Login'),
(42, 1, '2016', 'Oct', '2016-10-09', '05:10:25', 'Login'),
(43, 15, '2016', 'Oct', '2016-10-09', '05:10:55', 'Login'),
(44, 1, '2016', 'Oct', '2016-10-09', '08:18:36', 'Login'),
(45, 1, '2016', 'Oct', '2016-10-09', '08:21:33', 'Login'),
(46, 1, '2016', 'Oct', '2016-10-09', '11:05:08', 'Login'),
(47, 1, '2016', 'Oct', '2016-10-10', '17:39:47', 'Login'),
(48, 15, '2016', 'Oct', '2016-10-10', '17:43:15', 'Login'),
(49, 1, '2016', 'Oct', '2016-10-11', '18:38:09', 'Login'),
(50, 1, '2016', 'Oct', '2016-10-11', '18:38:33', 'Login'),
(51, 15, '2016', 'Oct', '2016-10-11', '06:55:59', 'Login'),
(52, 1, '2016', 'Oct', '2016-10-11', '07:43:12', 'Login'),
(53, 15, '2016', 'Oct', '2016-10-11', '07:43:53', 'Login'),
(54, 15, '2016', 'Oct', '2016-10-11', '07:43:58', 'Login'),
(55, 15, '2016', 'Oct', '2016-10-11', '07:51:11', 'Login'),
(56, 15, '2016', 'Oct', '2016-10-11', '07:52:36', 'Login'),
(57, 15, '2016', 'Oct', '2016-10-11', '08:19:46', 'Login'),
(58, 1, '2016', 'Oct', '2016-10-11', '08:35:58', 'Login'),
(59, 1, '2016', 'Oct', '2016-10-11', '09:59:31', 'Login'),
(60, 1, '2016', 'Oct', '2016-10-12', '05:53:43', 'Login'),
(61, 1, '2016', 'Oct', '2016-10-12', '16:19:35', 'Login'),
(62, 1, '2016', 'Oct', '2016-10-12', '16:20:48', 'Login'),
(63, 1, '2016', 'Oct', '2016-10-12', '16:21:02', 'Login'),
(64, 1, '2016', 'Oct', '2016-10-13', '14:50:02', 'Login'),
(65, 1, '2016', 'Oct', '2016-10-14', '16:43:35', 'Login'),
(66, 1, '2016', 'Oct', '2016-10-14', '16:47:15', 'Login'),
(67, 1, '2016', 'Oct', '2016-10-14', '16:50:08', 'Login'),
(68, 1, '2016', 'Oct', '2016-10-14', '16:50:25', 'Login'),
(69, 15, '2016', 'Oct', '2016-10-14', '16:58:35', 'Login'),
(70, 1, '2016', 'Oct', '2016-10-15', '07:36:26', 'Login'),
(71, 15, '2016', 'Oct', '2016-10-15', '07:36:48', 'Login'),
(72, 1, '2016', 'Oct', '2016-10-16', '12:42:46', 'Login'),
(73, 1, '2016', 'Oct', '2016-10-16', '16:12:00', 'Login'),
(74, 1, '2016', 'Oct', '2016-10-20', '07:06:43', 'Login'),
(75, 1, '2016', 'Oct', '2016-10-20', '07:09:47', 'Login'),
(76, 15, '2016', 'Oct', '2016-10-27', '05:24:24', 'Login'),
(77, 1, '2016', 'Oct', '2016-10-27', '05:29:22', 'Login'),
(78, 1, '2016', 'Nov', '2016-11-11', '18:20:21', 'Login'),
(79, 1, '2016', 'Nov', '2016-11-12', '12:02:03', 'Login'),
(80, 1, '2016', 'Nov', '2016-11-16', '13:12:33', 'Login'),
(81, 1, '2016', 'Nov', '2016-11-21', '12:14:59', 'Login');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_settings`
--
ALTER TABLE `account_settings`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `domestic_doc`
--
ALTER TABLE `domestic_doc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `excel`
--
ALTER TABLE `excel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`UL_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_settings`
--
ALTER TABLE `account_settings`
  MODIFY `AID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `domestic_doc`
--
ALTER TABLE `domestic_doc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `excel`
--
ALTER TABLE `excel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=633;
--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `UL_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
