<?php  include('../../core/int.php'); 




if(isset($_FILES['excel_file']) === true ) {

	$file = rand().$_FILES['excel_file']['name'];
$file_tmp = $_FILES['excel_file']['tmp_name'];	

$bill_no = $_POST['bill_no'];
$pick_date = $_POST['pick_date'];
$deli_date = $_POST['deli_date'];
$deli_time = $_POST['deli_time'];
$from = $_POST['from'];
$to = $_POST['to'];
$des = $_POST['des'];
$status = $_POST['status'];
$id = $_POST['bill_id'];
$bill_file = $_POST['bill_file'];

$delete_file = '../../dist/file/'.$bill_file;
unlink($delete_file);	

$file_path = '../../dist/file/'.$file;
move_uploaded_file($file_tmp, $file_path);

	if(!mysqli_query($con, "update excel set Bill_No = '$bill_no', File = '$file', Pick_Date = '$pick_date', Deli_Date = '$deli_date', Deli_Time = '$deli_time', From_City = '$from',  To_city = '$to', Des = '$des', Status = '$status'  where id = '$id'"))
	{
		echo 'Error :- '.mysqli_error($con);
	}

	

} else if(isset($_FILES['excel_file']) === false ) {

$bill_no = $_POST['bill_no'];
$pick_date = $_POST['pick_date'];
$deli_date = $_POST['deli_date'];
$deli_time = $_POST['deli_time'];
$from = $_POST['from'];
$to = $_POST['to'];
$des = $_POST['des'];
$status = $_POST['status'];
$id = $_POST['bill_id'];
$bill_file = $_POST['bill_file'];

	if(!mysqli_query($con, "update excel set Bill_No = '$bill_no',  Pick_Date = '$pick_date', Deli_Date = '$deli_date', Deli_Time = '$deli_time', From_City = '$from',  To_city = '$to', Des = '$des' , Status = '$status' where id = '$id'")) {
		echo 'Error :- '.mysqli_error($con);
	}
}

?>

      
