<?php  include('../../core/int.php');  

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$address = $_POST['message'];

if(!mysqli_query($con, "insert into contact (Name,Mobile,Email,Message) VALUES ('$name','$mobile','$email ','$address')")) {
	echo 'Error :- '.mysqli_error($con);
}
$Message = 'Name = '.$name.'<br />Email = '.$email.'<br />Mobile = '.$mobile.'<br />Message = '.$address;				
				 include("class.phpmailer.php");
					
					date_default_timezone_set('Asia/Calcutta');
					define('SMTP_HOST','mail.sbexpresscargo.com');
					define('SMTP_PORT',587);
					define('SMTP_USERNAME','info@sbexpresscargo.com');
					define('SMTP_PASSWORD','web@cargo1');
					define('SMTP_AUTH',true);
					 
					$mail  = new PHPMailer();
					$from  = 'info@sbexpresscargo.com';
					$mail->isSMTP();
					$mail->Host = SMTP_HOST;
					$mail->SMTPAuth = SMTP_AUTH;
					$mail->Username = SMTP_USERNAME;
					$mail->Password = SMTP_PASSWORD;
					$mail->Port = 587;
					$mail->SetFrom($from, $NA);
					$mail->AddReplyTo($from,$NA);
					$mail->Subject = 'Queries';
					$mail->MsgHTML($Message);
					$mail->AddAddress('info@sbexpresscargo.com', $name);
					
					$mail->IsHTML(true);
					if(!$mail->send())
					{
						echo "Mailer Error: " . $mail->ErrorInfo;
					}
 
 ?>
      
