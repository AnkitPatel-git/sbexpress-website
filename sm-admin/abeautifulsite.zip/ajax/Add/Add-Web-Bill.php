<?php  include('../../core/int.php');  



if(isset($_FILES['excel_file'])){	

$file = rand().$_FILES['excel_file']['name'];
$file_tmp = $_FILES['excel_file']['tmp_name'];	

$bill_no = $_POST['bill_no'];
$pick_date = $_POST['pick_date'];
$deli_date = $_POST['deli_date'];
$deli_time = $_POST['deli_time'];
$from = $_POST['from'];
$to = $_POST['to'];
$des = $_POST['des'];
$status = $_POST['status'];
$rand = rand();
$file_path = '../../dist/file/'.$file;
	

move_uploaded_file($file_tmp, $file_path);


if(!mysqli_query($con, "insert into excel(Bill_No, File, Pick_Date,Deli_Date,Deli_time,From_City,To_city,Des,Status,Rand) VALUES ('$bill_no', '$file',  '$pick_date','$deli_date', '$deli_time', '$from' , '$to', '$des', '$status', '$rand')")) {
	echo 'Error :- '.mysqli_error($con);
}
mysqli_query($con,"inser into users(Bill_No) values('$bill_no')");
}
 ?>
      
