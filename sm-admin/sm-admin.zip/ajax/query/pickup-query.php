<?php  include('../../core/int.php');  

$re_name = $_POST['requester_name'];
$re_company = $_POST['requester_company'];
$re_phone = $_POST['requester_phone'];
$re_email = $_POST['requester_mail'];
$re_address = $_POST['requester_address'];
$re_city = $_POST['requester_city'];
$pi_city = $_POST['pickup_city'];
$pi_phone = $_POST['pickup_phone'];
$pi_telephone = $_POST['pickup_telephone'];
$pi_email = $_POST['pickup_email'];
$dest_phone = $_POST['destination_phone'];
$dest_telephone = $_POST['destination_telephone'];
$dest_email = $_POST['destination_email'];
$dest_city = $_POST['destination_city'];
$weight = $_POST['weight'];
$pi_date = $_POST['pickup_date'];
$pi_address = $_POST['pickup_address'];
$dest_address = $_POST['destination_address'];
$content = $_POST['content'];
if(!mysqli_query($con, "insert into pickup (Re_Name,Re_Company,Re_Phone,Re_Email,Re_Address,Re_City,Pi_City,Pi_Phone,Pi_Telephone,Pi_Email,Dest_Phone,Dest_Telephone,Dest_Email,Dest_City,Dest_Address,Weight,Pi_Date,Pi_Address,Contents) VALUES ('$re_name','$re_company','$re_phone ','$re_email','$re_address','$re_city','$pi_city','$pi_phone', '$pi_telephone', '$pi_email', '$dest_phone', '$dest_telephone', '$dest_email', '$dest_city', '$dest_address', '$weight', '$pi_date', '$pi_address', '$content')")) {
	echo 'Error :- '.mysqli_error($con);
}

 
 ?>
      
